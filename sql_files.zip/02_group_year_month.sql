SELECT DISTINCT
    EXTRACT(YEAR FROM order_date) AS order_year,
    EXTRACT(MONTH FROM order_date) AS order_month
FROM online_sales
ORDER BY order_year, order_month;