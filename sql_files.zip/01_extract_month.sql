SELECT DISTINCT EXTRACT(MONTH FROM order_date) AS order_month
FROM online_sales
ORDER BY order_month;